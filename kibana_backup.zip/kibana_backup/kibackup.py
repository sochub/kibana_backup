#!/usr/bin/env python3
import requests
import argparse
import json
import sys
import gzip
import datetime
import boto3
import logging
import os
import io
from elasticsearch import Elasticsearch, RequestsHttpConnection
from elasticsearch.helpers import bulk
from requests_aws4auth import AWS4Auth

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def kibackup(event, context=None):
    # get kibana objects from API
    kibana_url = event.get('kibana_url')
    #AWS get credentials
    awsauth = AWS4Auth(os.environ['AWS_ACCESS_KEY_ID'], os.environ['AWS_SECRET_ACCESS_KEY'], os.environ['AWS_REGION'],
                       'es',
                       session_token=os.environ['AWS_SESSION_TOKEN'])
    #Kibana API save objects info
    url = "%s/_plugin/kibana/api/saved_objects/_find" % (kibana_url.rstrip("/"),)
    saved_object_types = ('visualization', 'dashboard', 'search', 'index-pattern', 'config')
    logger.info("downloading saved objects from "+kibana_url)
    for obj in saved_object_types:
        r = requests.get(url, auth=(awsauth), verify=False, params={'per_page': 10000,'type':obj})
        data = r.json()['saved_objects']
        logger.info("downloading: " + obj)
        # send objects to S3 processor
        tos3bucket(data, event, obj)


def tos3bucket(data, event, obj):
    # This take the data form the handler and put a bulk of events into a 
    # s3 bucket with gzip file. 
    logger.info("saving object on s3")
    region = event.get('region')
    name_prefix = obj
    awsauth = AWS4Auth(os.environ['AWS_ACCESS_KEY_ID'], os.environ['AWS_SECRET_ACCESS_KEY'], region,
                       'es',
                       session_token=os.environ['AWS_SESSION_TOKEN'])
    buf = io.BytesIO()
    s3 = boto3.resource('s3', region_name=os.environ['AWS_REGION'])
    year = datetime.datetime.now().strftime("%Y")
    month = datetime.datetime.now().strftime("%m")
    day = datetime.datetime.now().strftime("%d")
    nowD = datetime.datetime.now().strftime("%Y%m%d")
    nowT = datetime.datetime.now().strftime("%H%M%S")
    
    filename = name_prefix + nowD + 'T'+ nowT + ".ndjson.gz"

    with gzip.GzipFile(fileobj=buf, mode='wb') as gfh:
            with io.TextIOWrapper(gfh, encoding='utf-8') as wrapper:
                wrapper.write(json.dumps(data, ensure_ascii=False, default=None))
    buf.seek(0)
    bucketID = event.get('bucket')
    bucketKEY = event.get('bucket_prefix')
    logger.info("trying to save on:" + bucketID + ":" + bucketKEY + "/" + "kibana" + "/" + year + "/" + month + "/" + day + "/" + filename)
    key = bucketKEY + '/' + 'kibana' + '/' + year + '/' + month + '/' + day + '/' + filename
    s3.Bucket(bucketID).put_object(Key=key, Body=buf)
    logger.info("the file was saved on "+bucketID+"/"+key)

def main(argv):
    event = dict();
    event['kibana_url'] = argv.kibana_url
    event['bucket'] = argv.bucket
    event['bucket_prefix'] = argv.bucket_prefix

    kibackup(event)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-k', '--kibana-url'
    )
    parser.add_argument(
        '-b', '--bucket'
    )
    parser.add_argument(
        '-p', '--bucket-prefix'
    )
    args = parser.parse_args()
    main(args)