import requests
import argparse
import json
import sys
import gzip
import datetime
import boto3
import logging
import os
import io
from elasticsearch import Elasticsearch, RequestsHttpConnection
from elasticsearch.helpers import bulk
from requests_aws4auth import AWS4Auth